import React from 'react';
import { ShieldCheck, HeartPulse, Scale, Sparkles } from 'lucide-react';
import { TRUST_POINTS } from '../../data/canonicalCatalog';

export const TrustStrip: React.FC = () => {
  return (
    <section className="border-y border-[#CFDCC8] bg-gradient-to-r from-[#E5EEE0]/80 via-[#F3F8F0]/90 to-[#E5EEE0]/80 py-7 backdrop-blur-xs" aria-label="Credenciais e Pilares de Confiança">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
          {TRUST_POINTS.map((item, index) => (
            <div key={index} className="flex flex-col items-center md:items-start text-center md:text-left">
              <div className="flex items-center gap-2">
                <span className={`font-display text-2xl sm:text-3xl font-extrabold tracking-tight ${
                  index === 1 ? 'text-[#EB651A]' : 'text-[#2C6E14]'
                }`}>
                  {item.value}
                </span>
              </div>
              <span className="text-sm font-bold text-[#0A160F] mt-0.5">
                {item.label}
              </span>
              <span className="text-xs text-[#566D5D] mt-1 leading-snug font-medium">
                {item.description}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
