import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Menu, 
  X, 
  Activity, 
  PhoneCall, 
  Target, 
  FlaskConical, 
  Layers, 
  CreditCard, 
  ShieldCheck,
  ArrowRight,
  Calendar
} from 'lucide-react';
import { CLIENT_INFO } from '../../data/canonicalCatalog';
import { analytics } from '../../lib/analytics';
import { VISUAL_ASSETS } from '../../data/imageAssets';

interface HeaderProps {
  onOpenConcierge: (initialPrompt?: string) => void;
  onOpenTelemetry?: () => void;
  onOpenBooking?: (serviceId?: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenConcierge, onOpenBooking }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      setIsScrolled(scrollY > 20);

      const winHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      if (winHeight > 0) {
        setScrollProgress((scrollY / winHeight) * 100);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      analytics.track('navigation_click', 'header', { targetId: id });
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const navItems = [
    { label: 'Método', target: 'metodo', icon: Layers },
    { label: 'Programas', target: 'programas', icon: Activity },
    { label: 'Mapa Inicial', target: 'diagnostico', isHighlight: true, icon: Target },
    { label: 'Lab Interativo', target: 'lab-interativo', icon: FlaskConical },
    { label: 'Evidências', target: 'evidencias', icon: ShieldCheck },
    { label: 'Planos', target: 'planos', icon: CreditCard },
  ];

  return (
    <>
      {/* Precision Scroll Progress Indicator */}
      <div 
        className="fixed top-0 left-0 h-[3px] bg-gradient-to-r from-[#72B818] via-[#EB651A] to-[#198774] z-50 transition-all duration-150"
        style={{ width: `${scrollProgress}%` }}
        aria-hidden="true"
      />

      <header 
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled 
            ? 'bg-white/92 backdrop-blur-xl border-b border-[#CCD8C4] shadow-[0_6px_25px_rgba(20,40,25,0.06)] py-3' 
            : 'bg-gradient-to-b from-[#EDF4EA]/90 to-transparent backdrop-blur-xs py-4 sm:py-5'
        }`}
      >
        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 flex items-center justify-between">
          
          {/* 1. Left: Brand Identity with Symmetrical Micro-Elements */}
          <button 
            id="nav-logo-btn"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-3 text-left group focus:outline-none cursor-pointer select-none"
            aria-label="Dr. Tanutri Home"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#72B818] via-[#5D9F13] to-[#48800D] flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-transform duration-300">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="font-display text-xl sm:text-2xl font-extrabold tracking-tight text-[#0A160F] flex items-center gap-1.5">
                Dr.<span className="text-[#2C6E14]">Tanutri</span>
                <span className="w-2 h-2 rounded-full bg-[#EB651A] shadow-[0_0_8px_rgba(235,101,26,0.6)]" />
              </span>
              <span className="hidden sm:block text-[10px] uppercase tracking-widest text-[#566D5D] font-mono-data font-bold">
                Nutrição Esportiva & Precisão Clínica
              </span>
            </div>
          </button>

          {/* 2. Center: Desktop Balanced Navigation Pill */}
          <nav 
            className="hidden lg:flex items-center gap-1 xl:gap-2 px-3 py-1.5 rounded-full bg-white/75 border border-[#CCD8C4]/70 backdrop-blur-md shadow-xs text-xs font-semibold text-[#2C4032]" 
            aria-label="Navegação Principal"
          >
            {navItems.map((item) => (
              <button 
                key={item.target}
                id={`nav-${item.target}-btn`}
                onClick={() => scrollTo(item.target)} 
                className={`px-3 py-1.5 rounded-full transition-all duration-200 focus:outline-none cursor-pointer flex items-center gap-1.5 ${
                  item.isHighlight 
                    ? 'text-[#0A160F] bg-gradient-to-r from-[#FFF5EE] to-[#FFEFE5] border border-[#FDCDB3] hover:border-[#EB651A]' 
                    : 'text-[#384C3E] hover:text-[#0A160F] hover:bg-[#F0F6EC]'
                }`}
              >
                {item.isHighlight && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#EB651A] animate-pulse" />
                )}
                <span>{item.label}</span>
              </button>
            ))}
          </nav>

          {/* 3. Right: Symmetrical Action Hub */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            
            {/* Online Booking Trigger CTA */}
            {onOpenBooking && (
              <button
                id="header-booking-btn"
                onClick={() => {
                  analytics.track('booking_open_header', 'navigation');
                  onOpenBooking();
                }}
                className="min-h-[42px] hidden md:flex items-center gap-2 px-3 sm:px-3.5 py-1.5 rounded-xl bg-white/95 hover:bg-white border border-[#CCD8C4] hover:border-[#1B4D24] text-[#1B4D24] hover:shadow-[0_4px_14px_rgba(27,77,36,0.15)] transition-all text-xs font-bold cursor-pointer shadow-2xs active:scale-[0.98] group"
                title="Acessar Agenda Online e reservar horário"
              >
                <Calendar className="w-3.5 h-3.5 text-[#1B4D24] group-hover:scale-110 transition-transform" />
                <span>Ver Agenda Online</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#72B818] animate-pulse" />
              </button>
            )}

            {/* AI Concierge Trigger (Satin Pill com Clara Avatar Real) */}
            <button
              id="header-concierge-btn"
              onClick={() => {
                analytics.track('concierge_open', 'header_button');
                onOpenConcierge();
              }}
              className="min-h-[42px] flex items-center gap-2.5 px-3 sm:px-3.5 py-1.5 rounded-xl bg-gradient-to-br from-white via-[#FFF9F5] to-[#FFF2EA] border border-[#FDCDB3] text-[#A8450C] hover:border-[#EB651A] hover:bg-[#FFEAE0] hover:shadow-[0_4px_14px_rgba(235,101,26,0.18)] transition-all text-xs font-bold cursor-pointer shadow-xs active:scale-[0.98] group"
              aria-label="Conversar com a Assistente de IA"
              title="Tire dúvidas imediatas com nossa Assistente de IA"
            >
              <div className="relative w-6 h-6 rounded-full overflow-hidden border border-[#72B818] shrink-0 bg-[#E2ECE0] group-hover:scale-105 transition-transform">
                <img
                  src={VISUAL_ASSETS.conciergeAvatar?.src || ''}
                  alt="Clara - Assistente Dr. Tanutri"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top"
                />
                <span className="absolute bottom-0 right-0 w-1.5 h-1.5 rounded-full bg-[#25D366] border border-white" />
              </div>
              <span className="hidden sm:inline font-bold">Assistente de IA</span>
            </button>

            {/* Primary Action Button (Bio-Wellness Botanical Palette) */}
            <button
              id="header-primary-cta"
              onClick={() => scrollTo('diagnostico')}
              className="min-h-[42px] flex items-center gap-2 px-4.5 sm:px-5 py-2 rounded-xl bg-gradient-to-r from-[#1B4D24] via-[#245D2E] to-[#1B4D24] hover:from-[#EB651A] hover:to-[#D95510] text-white active:scale-[0.98] font-bold text-xs sm:text-sm transition-all duration-300 shadow-[0_4px_16px_rgba(27,77,36,0.22)] hover:shadow-[0_6px_22px_rgba(235,101,26,0.35)] cursor-pointer"
            >
              <span>Iniciar Diagnóstico</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#AEE938] group-hover:text-white" />
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="min-h-[42px] min-w-[42px] lg:hidden p-2 rounded-xl bg-white border border-[#CCD8C4] text-[#0A160F] hover:text-[#EB651A] hover:border-[#EB651A] flex items-center justify-center cursor-pointer shadow-xs transition-colors"
              aria-expanded={mobileMenuOpen}
              aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu - High-End Symmetrical Layout */}
      {mobileMenuOpen && (
        <div 
          className="fixed inset-0 z-50 bg-[#EDF4EA]/96 backdrop-blur-2xl lg:hidden flex flex-col justify-between p-6 animate-fadeIn text-[#0A160F]"
          role="dialog"
          aria-modal="true"
          aria-label="Menu de Navegação Mobile"
        >
          {/* Top Bar inside Drawer */}
          <div className="flex items-center justify-between border-b border-[#CCD8C4] pb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#72B818] to-[#559211] flex items-center justify-center text-white">
                <Activity className="w-4 h-4 text-white" />
              </div>
              <span className="font-display text-lg font-bold text-[#0A160F]">
                Dr.<span className="text-[#2C6E14]">Tanutri</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#EB651A] ml-1 inline-block" />
              </span>
            </div>

            <button
              id="mobile-menu-close-btn"
              onClick={() => setMobileMenuOpen(false)}
              className="w-10 h-10 rounded-xl bg-white border border-[#CCD8C4] text-[#0A160F] flex items-center justify-center shadow-xs cursor-pointer"
              aria-label="Fechar menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Items (Symmetrical Satin Cards) */}
          <div className="py-6 space-y-2.5 overflow-y-auto">
            {navItems.map((item) => {
              const IconComp = item.icon;
              return (
                <button 
                  key={item.target}
                  id={`mobile-nav-${item.target}`}
                  onClick={() => scrollTo(item.target)} 
                  className={`w-full p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all cursor-pointer shadow-xs ${
                    item.isHighlight
                      ? 'bg-gradient-to-r from-white via-[#FFF5EE] to-[#FFEFE5] border-[#FDCDB3] text-[#0A160F]'
                      : 'bg-white/85 border-[#CCD8C4] text-[#0A160F] hover:border-[#72B818]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      item.isHighlight ? 'bg-[#FFF0E6] text-[#EB651A]' : 'bg-[#EBF5E4] text-[#2C6E14]'
                    }`}>
                      <IconComp className="w-4 h-4" />
                    </div>
                    <span className="text-sm font-bold">{item.label}</span>
                  </div>

                  {item.isHighlight ? (
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#EB651A] text-white font-mono-data font-bold">
                      60 seg
                    </span>
                  ) : (
                    <ArrowRight className="w-4 h-4 text-[#8B9A8F]" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Action CTAs at bottom of Mobile Drawer */}
          <div className="pt-4 border-t border-[#CCD8C4] space-y-2.5">
            {onOpenBooking && (
              <button
                id="mobile-booking-btn"
                onClick={() => {
                  setMobileMenuOpen(false);
                  analytics.track('booking_open_mobile_menu', 'navigation');
                  onOpenBooking();
                }}
                className="min-h-[46px] w-full py-3 px-3 rounded-2xl bg-[#1B4D24] hover:bg-[#245D2E] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all"
              >
                <Calendar className="w-4 h-4 text-[#AEE938]" />
                <span>Ver Agenda Online (Vagas Abertas)</span>
              </button>
            )}

            <button
              id="mobile-concierge-btn"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenConcierge();
              }}
              className="min-h-[46px] w-full py-2.5 px-3 rounded-2xl bg-gradient-to-r from-white to-[#FFF5EE] border border-[#FDCDB3] text-[#A8450C] font-bold text-xs sm:text-sm flex items-center justify-center gap-2.5 shadow-xs cursor-pointer group"
            >
              <div className="relative w-6 h-6 rounded-full overflow-hidden border border-[#72B818] shrink-0 bg-[#E2ECE0]">
                <img
                  src={VISUAL_ASSETS.conciergeAvatar?.src || ''}
                  alt="Clara - Assistente Dr. Tanutri"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top"
                />
                <span className="absolute bottom-0 right-0 w-1.5 h-1.5 rounded-full bg-[#25D366] border border-white" />
              </div>
              <span>Tirar Dúvidas com a Assistente de IA</span>
            </button>

            <button
              id="mobile-whatsapp-btn"
              onClick={() => {
                setMobileMenuOpen(false);
                const text = encodeURIComponent('Olá! Gostaria de falar com a equipe da Dr. Tanutri sobre os programas de nutrição esportiva e clínica.');
                window.open(`https://wa.me/${CLIENT_INFO.whatsAppClean}?text=${text}`, '_blank');
              }}
              className="min-h-[46px] w-full py-3 rounded-2xl bg-[#EAF5E4] border border-[#CCD8C4] text-[#2C6E14] font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs cursor-pointer hover:bg-[#DEEED6]"
            >
              <PhoneCall className="w-4 h-4 text-[#EB651A]" />
              <span>Chamar no WhatsApp ({CLIENT_INFO.primaryWhatsApp})</span>
            </button>

            <button
              id="mobile-primary-btn"
              onClick={() => scrollTo('diagnostico')}
              className="min-h-[48px] w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#1B4D24] via-[#245D2E] to-[#1B4D24] hover:from-[#EB651A] hover:to-[#D95510] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all"
            >
              <span>Iniciar Mapa Inicial Gratuito</span>
              <ArrowRight className="w-4 h-4 text-[#AEE938]" />
            </button>
          </div>
        </div>
      )}
    </>
  );
};

