import React from 'react';
import { Activity, ShieldCheck, Heart, Instagram, PhoneCall } from 'lucide-react';
import { CLIENT_INFO } from '../../data/canonicalCatalog';

interface FooterProps {
  onOpenTelemetry?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenTelemetry }) => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-gradient-to-b from-[#E6EFE2] to-[#D8E6D3] border-t border-[#CCD8C4] pt-16 pb-12 text-[#384C3E]" aria-label="Rodapé do site">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-[#CCD8C4]">
          
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#72B818] to-[#51880F] text-white flex items-center justify-center shadow-xs">
                <Activity className="w-4 h-4" />
              </div>
              <span className="font-display text-xl font-bold text-[#0A160F]">
                Dr.<span className="text-[#2C6E14]">Tanutri</span>
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#EB651A] ml-1 align-baseline" />
              </span>
            </div>

            <p className="text-xs text-[#384C3E] max-w-sm leading-relaxed font-normal">
              {CLIENT_INFO.subtagline}
            </p>

            <div className="text-xs space-y-1 pt-2">
              <p className="text-[#0A160F] font-bold">{CLIENT_INFO.professionalCoordination}</p>
              <p className="font-mono-data text-[11px] text-[#EB651A] font-bold">{CLIENT_INFO.professionalRegistration}</p>
              <p className="text-[11px] text-[#566D5D]">{CLIENT_INFO.cityRegion}</p>
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-3">
            <span className="text-xs font-mono-data text-[#0A160F] uppercase tracking-wider block font-bold">
              Navegação
            </span>
            <ul className="space-y-2 text-xs">
              <li>
                <button id="footer-nav-metodo" onClick={() => scrollTo('metodo')} className="hover:text-[#EB651A] transition-colors cursor-pointer font-medium">
                  Método Dr. Tanutri
                </button>
              </li>
              <li>
                <button id="footer-nav-diagnostico" onClick={() => scrollTo('diagnostico')} className="hover:text-[#EB651A] transition-colors cursor-pointer font-medium">
                  Mapa Inicial (Diagnóstico 60s)
                </button>
              </li>
              <li>
                <button id="footer-nav-lab" onClick={() => scrollTo('lab-interativo')} className="hover:text-[#EB651A] transition-colors cursor-pointer font-medium">
                  Laboratório Interativo
                </button>
              </li>
              <li>
                <button id="footer-nav-programas" onClick={() => scrollTo('programas')} className="hover:text-[#EB651A] transition-colors cursor-pointer font-medium">
                  Programas & Protocolos
                </button>
              </li>
              <li>
                <button id="footer-nav-portal" onClick={() => scrollTo('portal-preview')} className="hover:text-[#EB651A] transition-colors cursor-pointer font-medium">
                  Portal do Cliente
                </button>
              </li>
              <li>
                <button id="footer-nav-planos" onClick={() => scrollTo('planos')} className="hover:text-[#EB651A] transition-colors cursor-pointer font-medium">
                  Planos & Add-ons
                </button>
              </li>
            </ul>
          </div>

          {/* Legal & Compliance */}
          <div className="md:col-span-4 space-y-3">
            <span className="text-xs font-mono-data text-[#0A160F] uppercase tracking-wider block font-bold">
              Conformidade & Ética
            </span>
            <div className="p-4 rounded-2xl bg-white/80 border border-[#CCD8C4] text-[11px] leading-relaxed text-[#384C3E] space-y-2 shadow-xs">
              <div className="flex items-center gap-1.5 text-[#2C6E14] font-bold">
                <ShieldCheck className="w-4 h-4 text-[#EB651A] shrink-0" />
                <span>Rigor CFN / CRN-3 / LGPD</span>
              </div>
              <p>
                As informações contidas neste WebApp têm caráter informativo e educacional. Simulações bioenergéticas e curvas glicêmicas são modelos ilustrativos e não substituem prescrição clínica ou médica individual.
              </p>
            </div>
            
            <div className="flex items-center gap-4 pt-1 text-xs">
              <a 
                id="footer-whatsapp-link"
                href={`https://wa.me/${CLIENT_INFO.whatsAppClean}`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-[#2C6E14] font-bold hover:text-[#EB651A] hover:underline"
              >
                <PhoneCall className="w-3.5 h-3.5 text-[#EB651A]" />
                <span>{CLIENT_INFO.primaryWhatsApp}</span>
              </a>
              <span className="text-[#CCD8C4]">•</span>
              <span className="text-xs text-[#566D5D] font-medium">{CLIENT_INFO.instagram}</span>
            </div>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#566D5D]">
          <p>© {new Date().getFullYear()} Dr. Tanutri. Todos os direitos reservados. Feito com rigor científico.</p>
          <div className="flex flex-wrap items-center gap-3 sm:gap-4 font-medium">
            <span className="hover:text-[#0A160F] cursor-pointer">Termos de Uso</span>
            <span>•</span>
            <span className="hover:text-[#0A160F] cursor-pointer">Política de Privacidade (LGPD)</span>
            <span>•</span>
            <span className="hover:text-[#0A160F] cursor-pointer">Segurança de Dados</span>
            {onOpenTelemetry && (
              <>
                <span>•</span>
                <button 
                  id="footer-telemetry-btn"
                  onClick={onOpenTelemetry}
                  className="hover:text-[#0A160F] text-[#566D5D] hover:underline cursor-pointer flex items-center gap-1.5"
                  title="Auditoria de Telemetria e Microconversões (LGPD)"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-[#198774] animate-pulse" />
                  <span>Auditoria de Telemetria</span>
                </button>
              </>
            )}
          </div>
        </div>

      </div>
    </footer>
  );
};
