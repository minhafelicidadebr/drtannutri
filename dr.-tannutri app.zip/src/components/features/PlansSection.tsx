import React, { useState } from 'react';
import { Check, Sparkles, ArrowRight, ShieldCheck, PlusCircle, ShoppingBag, X, MessageCircle } from 'lucide-react';
import { CANONICAL_PLANS, CANONICAL_ADDONS, CLIENT_INFO } from '../../data/canonicalCatalog';
import { PlanItem, AddonItem } from '../../types';
import { VISUAL_ASSETS } from '../../data/imageAssets';
import { analytics } from '../../lib/analytics';
import { AddonCard } from './addons/AddonCard';
import { AddonDetailModal } from './addons/AddonDetailModal';

interface PlansSectionProps {
  onSelectPlan: (plan: PlanItem) => void;
  onOpenConcierge: (prompt: string) => void;
  onOpenBooking?: (serviceId?: string) => void;
}

export const PlansSection: React.FC<PlansSectionProps> = ({ onSelectPlan, onOpenConcierge, onOpenBooking }) => {
  const [selectedAddonIds, setSelectedAddonIds] = useState<string[]>([]);
  const [activeModalAddon, setActiveModalAddon] = useState<AddonItem | null>(null);

  const handleSelect = (plan: PlanItem) => {
    analytics.track('plan_select', 'conversion', { planId: plan.id, price: plan.price });
    if (onOpenBooking) {
      onOpenBooking(plan.id);
    } else {
      onSelectPlan(plan);
    }
  };

  const handleToggleAddon = (addonId: string) => {
    setSelectedAddonIds((prev) => {
      const exists = prev.includes(addonId);
      const updated = exists ? prev.filter((id) => id !== addonId) : [...prev, addonId];
      analytics.track('addon_toggle', 'interaction', { addonId, selected: !exists });
      return updated;
    });
  };

  // Selected Addons calculations
  const selectedAddons = CANONICAL_ADDONS.filter((a) => selectedAddonIds.includes(a.id));
  const addonsTotalPrice = selectedAddons.reduce((acc, curr) => acc + (curr.numericPrice || 0), 0);

  const handleBookBundle = () => {
    analytics.track('addon_bundle_checkout', 'conversion', {
      addons: selectedAddons.map((a) => a.id).join(','),
      totalAddonPrice: addonsTotalPrice
    });
    const itemsList = selectedAddons.map((a) => `• ${a.name} (${a.price})`).join('\n');
    const text = encodeURIComponent(
      `Olá, Dr. Tanutri! Gostaria de agendar / contratar os seguintes Add-ons de Precisão:\n\n${itemsList}\n\nTotal adicional: R$ ${addonsTotalPrice}. Como podemos agendar?`
    );
    window.open(`https://wa.me/${CLIENT_INFO.whatsAppClean}?text=${text}`, '_blank');
  };

  return (
    <section id="planos" className="py-20 md:py-28 relative bg-gradient-to-b from-[#EBF4E8] via-[#F2F7F0] to-[#E9F3E6] border-y border-[#CCD8C4]" aria-labelledby="plans-title">
      <div className="max-w-[1180px] mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-white to-[#F2F8ED] border border-[#CCD8C4] text-[#1E3B27] text-xs font-mono-data mb-3 font-bold shadow-xs">
            <span className="w-2 h-2 rounded-full bg-[#EB651A] animate-pulse" />
            <span>ARQUITETURA DE INVESTIMENTO</span>
          </div>
          <h2 id="plans-title" className="font-display text-3xl sm:text-4xl md:text-5xl text-[#0A160F] tracking-tight font-bold">
            Transparência Total, Sem Letras Miúdas
          </h2>
          <p className="text-sm sm:text-base text-[#384C3E] mt-3 font-normal">
            Escolha entre uma porta de entrada pontual, um programa completo de transformação metabólica ou acompanhamento contínuo.
          </p>
        </div>

        {/* 4 Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {CANONICAL_PLANS.map((plan) => (
            <div
              key={plan.id}
              className={`rounded-3xl p-6 sm:p-7 flex flex-col justify-between transition-all relative ${
                plan.isPopular
                  ? 'bg-gradient-to-br from-white via-[#FAFDF7] to-[#EDF6E8] border-2 border-[#72B818] shadow-[0_16px_48px_rgba(114,184,24,0.18),0_4px_12px_rgba(20,40,25,0.06)] lg:-translate-y-2'
                  : 'bg-gradient-to-br from-white via-[#F9FCF7] to-[#EFF6EB] border border-[#CCD8C4] shadow-[0_10px_30px_rgba(20,40,25,0.06)] hover:shadow-[0_18px_44px_rgba(20,40,25,0.12)] hover:border-[#72B818]'
              }`}
            >
              {plan.isPopular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3.5 py-0.5 rounded-full bg-[#EB651A] text-white text-[11px] font-mono-data font-bold uppercase shadow-[0_2px_12px_rgba(235,101,26,0.35)]">
                  Mais Procurado
                </div>
              )}

              <div>
                <span className="text-xs font-mono-data text-[#C84A07] uppercase tracking-wider block mb-1 font-bold">
                  {plan.category === 'entrada' ? 'Porta de Entrada' : plan.category === 'programa' ? 'Transformação' : plan.category === 'recorrente' ? 'Sustentação' : 'Experiência VIP'}
                </span>

                <h3 className="font-display text-xl font-bold text-[#0A160F] mb-2">
                  {plan.name}
                </h3>

                <p className="text-xs text-[#566D5D] mb-4 min-h-[36px] leading-relaxed">
                  {plan.description}
                </p>

                <div className="pb-4 mb-4 border-b border-[#CCD8C4]">
                  <div className="text-2xl sm:text-3xl font-display font-black text-[#0A160F]">
                    {plan.price}
                  </div>
                  <span className="text-xs text-[#566D5D] font-mono-data block mt-0.5 font-medium">
                    {plan.period}
                  </span>
                </div>

                {/* Features list */}
                <ul className="space-y-2.5 mb-6 text-xs text-[#384C3E]">
                  {plan.features.map((f, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-[#2C6E14] shrink-0 mt-0.5" />
                      <span className="font-normal text-[#0A160F]">{f}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <button
                  id={`plan-select-btn-${plan.id}`}
                  onClick={() => handleSelect(plan)}
                  className={`w-full min-h-[44px] py-3 rounded-2xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs ${
                    plan.isPopular
                      ? 'bg-[#EB651A] text-white hover:bg-[#C84A07] shadow-md hover:scale-102 active:scale-98'
                      : 'bg-white text-[#0A160F] border border-[#CCD8C4] hover:border-[#72B818] hover:bg-[#F2F8ED]'
                  }`}
                >
                  <span>{plan.ctaLabel}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                {plan.disclaimer && (
                  <p className="text-[10px] text-[#566D5D] text-center mt-2.5 font-medium">
                    {plan.disclaimer}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Add-ons Section - Exames & Serviços Complementares */}
        <div id="add-ons-precisao" className="rounded-3xl bg-gradient-to-br from-white via-[#F8FAF5] to-[#EEF5E9] border border-[#CCD8C4] p-6 sm:p-8 md:p-10 shadow-[0_16px_50px_rgba(20,40,25,0.08)]">
          {/* Section Sub-Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8 pb-6 border-b border-[#CCD8C4]">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1B4D24]/10 text-[#1B4D24] text-xs font-mono-data font-bold uppercase tracking-wider mb-2">
                <Sparkles className="w-3.5 h-3.5 text-[#1B4D24]" />
                <span>Exames & Serviços Complementares</span>
              </div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#0A160F] tracking-tight">
                Add-ons de Precisão
              </h3>
              <p className="text-xs sm:text-sm text-[#566D5D] mt-1.5 leading-relaxed">
                Tecnologia diagnóstica, telemetria contínua e autonomia prática de cozinha. Opcionais disponíveis para qualquer paciente, com ou sem plano associado.
              </p>
            </div>
            
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs text-[#566D5D] font-medium bg-white px-3.5 py-1.5 rounded-full border border-[#CCD8C4] shadow-2xs flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-[#1B4D24]" />
                <span>Opcionais disponíveis para qualquer paciente</span>
              </span>
            </div>
          </div>

          {/* 3 Add-on Cards Grid with Hollywood Studio Imagery */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {CANONICAL_ADDONS.map((addon) => (
              <AddonCard
                key={addon.id}
                addon={addon}
                isSelected={selectedAddonIds.includes(addon.id)}
                onToggleSelect={handleToggleAddon}
                onOpenDetails={(targetAddon) => {
                  analytics.track('addon_detail_view', 'interaction', { addonId: targetAddon.id });
                  setActiveModalAddon(targetAddon);
                }}
                onOpenConcierge={onOpenConcierge}
              />
            ))}
          </div>

          {/* Interactive Simulation Drawer / Bundle Tray */}
          {selectedAddons.length > 0 ? (
            <div className="mt-8 p-5 sm:p-6 rounded-2xl bg-[#0A160F] text-white border border-[#1B4D24] shadow-[0_12px_35px_rgba(10,22,15,0.3)] animate-fadeIn">
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-[#1B4D24] flex items-center justify-center text-[#AEE938]">
                      <ShoppingBag className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-mono-data uppercase tracking-wider text-[#AEE938] font-bold">
                      Simulador de Pacote Personalizado
                    </span>
                    <span className="text-xs bg-white/15 px-2 py-0.5 rounded-md font-mono-data">
                      {selectedAddons.length} {selectedAddons.length === 1 ? 'item' : 'itens'}
                    </span>
                  </div>

                  {/* Selected Items Pills */}
                  <div className="flex flex-wrap gap-2 pt-1">
                    {selectedAddons.map((item) => (
                      <span 
                        key={item.id}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium border border-white/15 transition-colors"
                      >
                        <span>{item.name.split(' (')[0]}</span>
                        <span className="text-[#AEE938] font-mono-data font-bold">{item.price}</span>
                        <button
                          onClick={() => handleToggleAddon(item.id)}
                          aria-label={`Remover ${item.name}`}
                          className="hover:text-red-400 p-0.5 cursor-pointer ml-1"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>

                {/* Pricing Calculation & CTA */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full lg:w-auto shrink-0 pt-3 lg:pt-0 border-t lg:border-t-0 border-white/15">
                  <div>
                    <span className="text-[11px] font-mono-data text-white/70 block uppercase">
                      Investimento Adicional
                    </span>
                    <div className="text-2xl sm:text-3xl font-mono-data font-black text-[#AEE938] leading-none mt-0.5">
                      R$ {addonsTotalPrice}
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 w-full sm:w-auto">
                    <button
                      id="bundle-whatsapp-checkout-btn"
                      onClick={handleBookBundle}
                      className="min-h-[46px] flex-1 sm:flex-none px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#72B818] to-[#5C9B14] hover:opacity-95 text-[#0A160F] font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Agendar no WhatsApp</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>

                    <button
                      id="bundle-clear-btn"
                      onClick={() => setSelectedAddonIds([])}
                      className="min-h-[46px] px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white/80 hover:text-white text-xs font-medium transition-colors cursor-pointer"
                      title="Limpar seleção"
                    >
                      Limpar
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Subtle Help Banner when none is selected */
            <div className="mt-8 p-4 sm:p-5 rounded-2xl bg-white/70 border border-[#CCD8C4] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#384C3E]">
              <div className="flex items-center gap-3">
                <img 
                  src={VISUAL_ASSETS.conciergeAvatar.src}
                  alt="Clara"
                  className="w-9 h-9 rounded-full object-cover border-2 border-[#CCD8C4] shrink-0"
                />
                <p>
                  Não tem certeza de qual add-on agregaria mais resultado ao seu momento atual?
                </p>
              </div>
              <button
                id="addons-concierge-guidance-btn"
                onClick={() => onOpenConcierge('Olá! Gostaria de uma recomendação clínica sobre quais add-ons (Bioimpedância InBody, Sensor de Glicose ou Meal Prep) fariam mais diferença para meu caso.')}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-white border border-[#CCD8C4] hover:border-[#1B4D24] text-[#1B4D24] font-bold flex items-center gap-1.5 shrink-0 cursor-pointer shadow-2xs hover:shadow-xs transition-all"
              >
                <span>Pedir orientação à Clara</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Modal for Add-on Deep Dive */}
        <AddonDetailModal
          addon={activeModalAddon}
          isOpen={!!activeModalAddon}
          onClose={() => setActiveModalAddon(null)}
          onOpenConcierge={onOpenConcierge}
          onToggleSelect={handleToggleAddon}
          isSelected={activeModalAddon ? selectedAddonIds.includes(activeModalAddon.id) : false}
          onOpenBooking={onOpenBooking}
        />

      </div>
    </section>
  );
};
