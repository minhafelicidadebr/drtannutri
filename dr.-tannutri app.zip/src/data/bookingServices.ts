import { BookingServiceItem, TimeSlot } from '../types/booking';

export const BOOKING_SERVICES: BookingServiceItem[] = [
  // 1. Planos de Entrada & Diagnóstico
  {
    id: 'diagnostico_inicial',
    name: 'Diagnóstico Inicial Metabólico (75 min)',
    category: 'plano',
    categoryLabel: 'Porta de Entrada',
    price: 'R$ 450',
    duration: '75 min',
    description: 'Consulta profunda com mapeamento de rotina, análise de sinais clínicos, exames de sangue e plano de ação imediato.',
    highlight: 'Mais Recomendado para Primeiro Contato',
    modalitiesAllowed: ['presencial', 'online']
  },
  {
    id: 'programa_90d',
    name: 'Programa de Transformação Metabólica (90 dias)',
    category: 'protocolo',
    categoryLabel: 'Programa Completo',
    price: 'R$ 1.680',
    duration: '90 dias (6 consultas)',
    description: 'Acompanhamento contínuo em 3 fases (Reset, Adaptação e Consolidação) com suporte direto e ajustes quinzenais.',
    highlight: 'Maior Taxa de Sucesso e Adesão',
    modalitiesAllowed: ['presencial', 'online']
  },
  {
    id: 'performance_vip',
    name: 'Protocolo de Alta Demanda & Atletas VIP',
    category: 'protocolo',
    categoryLabel: 'Experiência VIP',
    price: 'R$ 2.450',
    duration: '120 dias intensivos',
    description: 'Periodização de carboidratos, suplementação ergogênica baseada em lactato/VO2 e canal prioritário 24/7.',
    highlight: 'Atletas e Executivos',
    modalitiesAllowed: ['presencial', 'online']
  },
  {
    id: 'acompanhamento_mensal',
    name: 'Consulta Avulsa de Retorno & Sustentação',
    category: 'plano',
    categoryLabel: 'Sustentação',
    price: 'R$ 380',
    duration: '45 min',
    description: 'Para pacientes que já passaram pelo diagnóstico inicial e desejam calibrar macronutrientes e conferir evolução.',
    modalitiesAllowed: ['presencial', 'online']
  },

  // 2. Add-ons de Precisão
  {
    id: 'bioimpedancia_inbody',
    name: 'Exame de Bioimpedância Segmentada InBody 770',
    category: 'addon',
    categoryLabel: 'Diagnóstico Hospitalar',
    price: 'R$ 150',
    duration: '20 min',
    description: 'Análise segmentada direta: água intra/extracelular, massa muscular por membro, gordura visceral e ângulo de fase.',
    highlight: 'Padrão Ouro Clínico',
    modalitiesAllowed: ['presencial'] // Presencial apenas
  },
  {
    id: 'sensor_glicose',
    name: 'Sensor Contínuo de Glicose + Relatório (14 dias)',
    category: 'addon',
    categoryLabel: 'Biotecnologia',
    price: 'R$ 490',
    duration: '14 dias telemetria',
    description: 'Instalação ou envio do sensor intersticial com auditoria fotográfica e curva glicêmica personalizada.',
    highlight: 'Telemetria 24/7',
    modalitiesAllowed: ['presencial', 'online']
  },
  {
    id: 'consultoria_cozinha',
    name: 'Consultoria de Cozinha & Meal Prep Prático',
    category: 'addon',
    categoryLabel: 'Rotina & Autonomia',
    price: 'R$ 280',
    duration: '60 min ao vivo',
    description: 'Sessão individual online para organizar despensa, batch cooking funcional e marmitas da semana em 2h.',
    highlight: 'Economia & Agilidade',
    modalitiesAllowed: ['online']
  }
];

/**
 * Generates mock intelligent slots for a given date based on clinic hours
 */
export function generateTimeSlotsForDate(date: Date): TimeSlot[] {
  const dayOfWeek = date.getDay(); // 0 = Domingo, 6 = Sábado
  if (dayOfWeek === 0) {
    return []; // Domingo fechado
  }

  // Sábado tem expediente reduzido
  if (dayOfWeek === 6) {
    return [
      { id: 's1', time: '08:30', period: 'manha', label: '08:30 - Manhã', available: true, isFastingRecommended: true },
      { id: 's2', time: '09:45', period: 'manha', label: '09:45 - Manhã', available: false, isFastingRecommended: true },
      { id: 's3', time: '11:00', period: 'manha', label: '11:00 - Manhã', available: true, isFastingRecommended: false },
      { id: 's4', time: '12:15', period: 'tarde', label: '12:15 - Tarde', available: true, isFastingRecommended: false }
    ];
  }

  // Dias úteis (Segunda a Sexta)
  return [
    // Turno Manhã (Foco em Jejum e Bioimpedância)
    { id: 'm1', time: '08:00', period: 'manha', label: '08:00 - Jejum Ideal', available: true, isFastingRecommended: true },
    { id: 'm2', time: '09:15', period: 'manha', label: '09:15 - Jejum Ideal', available: true, isFastingRecommended: true },
    { id: 'm3', time: '10:30', period: 'manha', label: '10:30 - Manhã', available: false, isFastingRecommended: true },
    { id: 'm4', time: '11:45', period: 'manha', label: '11:45 - Manhã', available: true, isFastingRecommended: false },

    // Turno Tarde
    { id: 't1', time: '14:00', period: 'tarde', label: '14:00 - Tarde', available: true, isFastingRecommended: false },
    { id: 't2', time: '15:15', period: 'tarde', label: '15:15 - Tarde', available: true, isFastingRecommended: false },
    { id: 't3', time: '16:30', period: 'tarde', label: '16:30 - Tarde', available: true, isFastingRecommended: false },

    // Turno Executivo / Noite
    { id: 'n1', time: '17:45', period: 'noite', label: '17:45 - Executivo', available: true, isFastingRecommended: false },
    { id: 'n2', time: '19:00', period: 'noite', label: '19:00 - Noturno', available: false, isFastingRecommended: false }
  ];
}
