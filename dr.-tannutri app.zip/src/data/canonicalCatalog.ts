import { ProgramItem, PlanItem, AddonItem, FAQItem } from '../types';

export const CLIENT_INFO = {
  brandName: "Dr. Tanutri",
  tagline: "Nutrição de Precisão & Acompanhamento Contínuo",
  subtagline: "A ciência do seu metabolismo traduzida em comida real, dados compreensíveis e suporte ativo.",
  segment: "Nutrição Clínica Funcional, Precisão Metabólica & Saúde Integrativa",
  cityRegion: "Consultas Presenciais & Atendimento Online Nacional e Internacional",
  primaryWhatsApp: "+55 11 99876-5432",
  whatsAppClean: "5511998765432",
  professionalCoordination: "Coordenação de Nutrição Clínica & Precisão Metabólica",
  professionalRegistration: "Prática Ética Conforme Resoluções CFN / CRN (Demonstração Institucional)",
  bookingUrl: "https://agendamento.drtanutri.com.br",
  instagram: "@drtanutri.oficial",
  guaranteeNotice: "Todas as simulações e projeções interativas têm finalidade exclusivamente educativa e ilustrativa. Condutas nutricionais e terapêuticas são individualizadas em consulta médica e nutricional, conforme as diretrizes do CFN/CRN.",
};

export const CANONICAL_PROGRAMS: ProgramItem[] = [
  {
    id: "metabolismo_precisao",
    name: "Metabolismo de Precisão",
    tagline: "Recomposição corporal e flexibilidade metabólica sustentável",
    duration: "12 semanas estruturadas",
    targetAudience: "Pessoas que sentem o metabolismo lento, convivem com efeito sanfona ou querem perder gordura preservando massa muscular.",
    bestFor: ["composicao_corporal", "energia_disposicao"],
    description: "Um protocolo aprofundado que analisa seu perfil hormonal, resposta à glicose e estilo de vida para construir uma alimentação prazerosa com alta densidade nutricional.",
    highlights: [
      "4 consultas presenciais ou online completas",
      "Bioimpedância segmentada de alta precisão (InBody)",
      "Plano alimentar dinâmico ajustado a cada quinzena",
      "Canal prioritário de WhatsApp com a equipe nutricional",
      "Acesso completo ao Portal do Cliente Dr. Tanutri"
    ],
    includes: [
      "Rastreamento de sintomas e digestão",
      "Guia de substituições inteligentes e lista de compras",
      "Estratégia de timing de nutrientes e micronutrientes",
      "Relatório metabólico visual quinzenal"
    ],
    priceEstimate: "R$ 1.890 (ou 3x de R$ 670)",
    badge: "Mais Recomendado",
    isPopular: true
  },
  {
    id: "vitalidade_digestiva",
    name: "Vitalidade & Saúde Digestiva",
    tagline: "Equilíbrio da microbiota, desinflamação e clareza mental",
    duration: "8 semanas de modulação",
    targetAudience: "Para quem lida com inchaço frequente, constipação, fadiga pós-refeição ou sensibilidades alimentares.",
    bestFor: ["saude_digestiva", "energia_disposicao"],
    description: "Protocolo clínico focado no eixo intestino-cérebro. Recupera a barreira intestinal, modula a microbiota e elimina os gatilhos inflamatórios sem dietas restritivas punitivas.",
    highlights: [
      "3 consultas clínicas direcionadas ao trato gastrointestinal",
      "Protocolo dos 5Rs da saúde intestinal em fases claras",
      "Guia anti-inflamatório gastronômico prático",
      "Acompanhamento semanal de sintomas digestivos via portal",
      "Avaliação e indicação de pré e probióticos de precisão"
    ],
    includes: [
      "Check-in semanal de trânsito intestinal e energia",
      "Receitas funcionais ricas em fibras prebióticas",
      "Estratégia de modulação de histamina e FODMAPs quando necessário"
    ],
    priceEstimate: "R$ 1.480 (ou 3x de R$ 520)",
    badge: "Foco Digestivo"
  },
  {
    id: "performance_longevidade",
    name: "Performance & Longevidade",
    tagline: "Eficiência mitocondrial, potência esportiva e envelhecimento saudável",
    duration: "12 semanas integradas",
    targetAudience: "Praticantes de corrida, triathlon, musculação intensa e executivos de alta demanda que buscam rendimento cognitivo e físico.",
    bestFor: ["performance_esportiva", "longevidade_metabolica"],
    description: "Periodização nutricional sincronizada aos blocos de treino. Otimização do uso de substratos energéticos, recuperação acelerada e controle de marcadores de estresse oxidativo.",
    highlights: [
      "4 consultas com periodização nutricional por ciclo de treino",
      "Estratégia intra-treino, pré e pós-treino sob medida",
      "Acompanhamento opcional com sensor contínuo de glicose (CGM)",
      "Suporte direto para dias de provas ou treinos de alta intensidade",
      "Parceria e alinhamento com seu treinador físico"
    ],
    includes: [
      "Cálculo exato de taxa de sudorese e reposição de eletrólitos",
      "Estratégia de sono restaurador e crononutrição",
      "Bioimpedância segmentada evolutiva a cada 30 dias"
    ],
    priceEstimate: "R$ 2.450 (ou 3x de R$ 860)",
    badge: "Alta Demanda"
  },
  {
    id: "assinatura_continua",
    name: "Acompanhamento Contínuo (Assinatura)",
    tagline: "Sustentação dos resultados com flexibilidade para a vida real",
    duration: "Recorrência mensal (sem fidelidade mínima)",
    targetAudience: "Para quem já atingiu a fase aguda ou deseja suporte constante sem recaídas, ajustando a dieta a viagens e novas rotinas.",
    bestFor: ["composicao_corporal", "longevidade_metabolica"],
    description: "A tranquilidade de ter um nutricionista e uma plataforma de dados sempre com você. Ajustes pontuais, revisão de exames de rotina e motivação constante.",
    highlights: [
      "1 consulta remota ou presencial mensal",
      "Check-ins quinzenais assíncronos no portal",
      "Canal de dúvidas no app com resposta em até 24h úteis",
      "Revisão contínua de cardápio para férias, eventos e rotinas novas"
    ],
    includes: [
      "Desconto exclusivo em bioimpedâncias e add-ons",
      "Acesso ininterrupto às ferramentas do portal do cliente"
    ],
    priceEstimate: "R$ 290 / mês",
    badge: "Recorrente"
  }
];

export const CANONICAL_PLANS: PlanItem[] = [
  {
    id: "diagnostico_inicial",
    name: "Diagnóstico Inicial de Precisão",
    category: "entrada",
    price: "R$ 380",
    period: "sessão única de 75 minutos",
    description: "A porta de entrada ideal: análise minuciosa do seu histórico, sinais clínicos, rotina e elaboração do plano de largada.",
    features: [
      "Consulta individual completa (75 min)",
      "Bioimpedância clínica segmentada (InBody)",
      "Mapeamento metabólico e de hábitos de vida",
      "Definição das 3 prioridades nutricionais imediatas",
      "Entrega do Plano-Piloto individualizado em até 48h",
      "Crédito integral do valor caso migre para um Programa em 15 dias"
    ],
    ctaLabel: "Agendar Diagnóstico",
    isPopular: false,
    disclaimer: "Ideal para quem quer conhecer a metodologia antes de um programa completo."
  },
  {
    id: "programa_metabolico",
    name: "Programa Metabolismo 12 Semanas",
    category: "programa",
    price: "R$ 1.890",
    period: "ou 3x de R$ 670 no cartão",
    description: "O formato mais procurado e com maior taxa de consolidação de hábitos e recomposição corporal.",
    features: [
      "4 consultas presenciais ou online com nutricionista titular",
      "Bioimpedâncias evolutivas segmentadas inclusas",
      "Plano alimentar vivo, atualizado quinzenalmente",
      "Canal de suporte ativo no WhatsApp para dúvidas cotidianas",
      "Acesso completo ao Portal do Cliente com receitas e check-ins",
      "Análise aprofundada de exames laboratoriais prévios"
    ],
    ctaLabel: "Garantir Vaga no Programa",
    isPopular: true,
    disclaimer: "Atendimento com vagas limitadas para garantir suporte individual de excelência."
  },
  {
    id: "plano_assinatura",
    name: "Assinatura Acompanhamento Contínuo",
    category: "recorrente",
    price: "R$ 290",
    period: "por mês • sem carência de permanência",
    description: "A certeza de manter o ritmo após a fase inicial ou para quem prefere evolução constante e sem pressão.",
    features: [
      "1 consulta mensal de alinhamento com a equipe",
      "Check-ins quinzenais com ajuste de metas no portal",
      "Suporte para adaptação a viagens, festas e períodos atípicos",
      "Desconto de 20% em exames e bioimpedâncias extras",
      "Cancelamento simples a qualquer momento com 1 clique"
    ],
    ctaLabel: "Assinar Acompanhamento",
    isPopular: false,
    disclaimer: "Válido para continuidade pós-diagnóstico ou pós-programa."
  },
  {
    id: "programa_longevidade_vip",
    name: "Performance & Longevidade Integrada",
    category: "premium",
    price: "R$ 2.450",
    period: "ou 3x de R$ 860 no cartão",
    description: "A experiência máxima de nutrição funcional e esportiva com monitoramento estreito e integração de rotina.",
    features: [
      "Tudo incluído no Programa de 12 Semanas",
      "Sincronização direta com plano de treino e periodização esportiva",
      "Acompanhamento e interpretação de sensor de glicose (CGM opcional)",
      "Consultoria de meal prep e estratégias para viagens de negócios",
      "Atendimento prioritário com tempo de resposta estendido"
    ],
    ctaLabel: "Quero a Experiência Completa",
    isPopular: false,
    disclaimer: "Recomendado para atletas amadores, executivos e alta demanda física/cognitiva."
  }
];

export const CANONICAL_ADDONS: AddonItem[] = [
  {
    id: "bioimpedancia_inbody",
    name: "Exame de Bioimpedância Segmentada InBody 770",
    category: "Diagnóstico",
    price: "R$ 150",
    numericPrice: 150,
    description: "Análise com laudo detalhado de água intracelular, gordura visceral, massa muscular por membro e taxa metabólica real.",
    benefit: "Permite calibrar com exatidão a ingestão proteica e checar retenção hídrica.",
    imageKey: "addonInBody",
    badge: "Padrão Ouro Clínico",
    durationOrFormat: "Presencial • 20 min",
    suitableFor: "Recomposição corporal, controle de retenção hídrica e avaliação segmentada de assimetrias.",
    clinicalSpecs: [
      "Água Intracelular e Extracelular (ICW/ECW)",
      "Massa Muscular Esquelética por membro",
      "Nível e Área de Gordura Visceral (VFA)",
      "Ângulo de Fase (saúde e integridade celular)",
      "Taxa Metabólica Basal (TMB) calculada com precisão"
    ],
    preparationTips: [
      "Jejum alimentar de 2 a 3 horas antes do exame",
      "Evitar exercícios físicos intensos nas 12h anteriores",
      "Esvaziar a bexiga cerca de 15 minutos antes da medição",
      "Não ingerir bebidas alcoólicas nas 24h que antecedem"
    ]
  },
  {
    id: "sensor_glicose",
    name: "Sensor Contínuo de Glicose + Análise de Dados (14 dias)",
    category: "Biotecnologia",
    price: "R$ 490",
    numericPrice: 490,
    description: "Instalação do sensor intersticial e relatório de tolerância glicêmica personalizada para diferentes refeições.",
    benefit: "Descubra como seu corpo específico reage a aveia, frutas, massas e treinos.",
    imageKey: "addonCgmSensor",
    badge: "Telemetria 24/7",
    durationOrFormat: "Sensor 14 dias + Relatório Clínico",
    suitableFor: "Pico de insulina subclínico, fadiga pós-prandial, atletas que buscam timing de carboidratos e pré-diabetes.",
    clinicalSpecs: [
      "Monitoramento intersticial ininterrupto por 14 dias",
      "Curva de resposta glicêmica para cada refeição típica",
      "Identificação de quedas reativas (hipoglicemia e fadiga)",
      "Correlação com picos de sono, estresse e exercício",
      "Relatório comparativo de tolerância a carboidratos reais"
    ],
    preparationTips: [
      "Aplicação indolor e rápida na parte posterior do braço",
      "Resistente à água (banho, natação e treinos intensos)",
      "Sincronização direta via smartphone (iOS/Android)",
      "Diário fotográfico das refeições durante o período"
    ]
  },
  {
    id: "consultoria_cozinha",
    name: "Consultoria de Cozinha & Meal Prep Prático (Online)",
    category: "Rotina",
    price: "R$ 280",
    numericPrice: 280,
    description: "Sessão prática de 60 minutos para organizar despensa, congelamento correto e montagem de marmitas funcionais em 2h por semana.",
    benefit: "Elimina a desculpa da falta de tempo e barateia o supermercado.",
    imageKey: "addonMealPrep",
    badge: "Autonomia & Economia",
    durationOrFormat: "Online ao Vivo • 60 min",
    suitableFor: "Profissionais com rotina corrida, pessoas que gastam muito com delivery ou desperdiçam comida da feira.",
    clinicalSpecs: [
      "Auditoria de despensa e utensílios indispensáveis",
      "Técnicas de pré-preparo e cozimento em lote (batch cooking)",
      "Congelamento correto que preserva nutrientes e textura",
      "Montagem de 10 a 14 refeições funcionais em até 2 horas",
      "Checklist inteligente de compras sazonais de baixo custo"
    ],
    preparationTips: [
      "Sessão individual online por videoconferência HD",
      "Acesso direto à sua cozinha para orientações em tempo real",
      "Guia PDF complementar com cronograma de preparo",
      "Tira-dúvidas direto por 7 dias após a consultoria"
    ]
  }
];

export const CANONICAL_FAQS: FAQItem[] = [
  {
    id: "faq-1",
    question: "Como funciona o primeiro contato e o Diagnóstico Inicial?",
    answer: "O Diagnóstico Inicial é uma consulta detalhada de 75 minutos (presencial em SP ou online com envio prévio de orientações). Investigamos seu histórico de saúde, sinais clínicos (digestão, sono, energia), preferências de paladar e exames de sangue recentes. Você não sai com um cardápio engessado de gaveta, e sim com um plano de ação claro para os primeiros 14 dias.",
    category: "metodo"
  },
  {
    id: "faq-2",
    question: "Vou receber uma dieta restritiva e proibitiva?",
    answer: "Absolutamente não. Nosso princípio é 'adição antes de subtração'. A ciência mostra que dietas baseadas em restrições severas aumentam o cortisol, geram rebote compulsivo e destroem a adesão. Trabalhamos com equilíbrio de macronutrientes, combinações inteligentes e prazer gastronômico adaptado ao seu gosto.",
    category: "metodo"
  },
  {
    id: "faq-3",
    question: "O atendimento online tem a mesma eficácia do presencial?",
    answer: "Sim. Nosso portal do cliente, canal ativo de comunicação e relatórios fotográficos de refeições proporcionam um nível de proximidade que muitas vezes supera o modelo tradicional de consultório a cada 30 dias. Para pacientes de fora de São Paulo, orientamos medições seguras de composição corporal em clínicas parceiras locais.",
    category: "programas"
  },
  {
    id: "faq-4",
    question: "Como a tecnologia e as ferramentas do WebApp me ajudam no dia a dia?",
    answer: "As ferramentas interativas (como o Gêmeo Metabólico, a Curva Glicêmica e o Simulador de Cenários) ajudam você a visualizar a lógica fisiológica por trás das orientações. Em vez de apenas seguir ordens, você compreende o 'porquê' de cada combinação, o que constrói autonomia permanente.",
    category: "tecnologia"
  },
  {
    id: "faq-5",
    question: "A Assistente de IA substitui a consulta com o nutricionista?",
    answer: "Não. A nossa Assistente de IA é estritamente comercial, educativa e de suporte à navegação. Ela ajuda a tirar dúvidas sobre os programas, explicar conceitos metabólicos gerais e preparar seu pré-diagnóstico. O diagnóstico clínico, plano dietoterápico e condutas individuais são atos exclusivos e humanos de nossa equipe nutricional habilitada.",
    category: "tecnologia"
  },
  {
    id: "faq-6",
    question: "Posso utilizar exames de sangue que fiz recentemente?",
    answer: "Com certeza. Exames realizados nos últimos 6 meses são extremamente bem-vindos e enriquecem muito nossa análise inicial de perfil lipídico, glicêmico, tireoidiano, inflamatório e de vitaminas/minerais.",
    category: "agendamento"
  }
];

export const METHOD_PILLARS = [
  {
    step: "01",
    title: "Diagnóstico Bioindividual",
    subtitle: "Mapeamento além do peso na balança",
    description: "Investigamos sua saúde mitocondrial, tolerância a carboidratos, microbiota intestinal e ciclo circadiano. O corpo não mente quando sabemos ler os sinais certos.",
    badge: "Precisão Clínica"
  },
  {
    step: "02",
    title: "Nutrição Gastronômica Real",
    subtitle: "Comida densa em nutrientes, zero punição",
    description: "A alimentação precisa caber na sua rotina de trabalho e família. Ingredientes frescos, técnicas culinárias simples e sabor que gera prazer verdadeiro, sem alimentos ultraprocessados disfarçados.",
    badge: "Alta Adesão"
  },
  {
    step: "03",
    title: "Acompanhamento Ativo & Vivo",
    subtitle: "Apoio entre as consultas, quando a vida acontece",
    description: "O maior gargalo das dietas tradicionais é a solidão entre consultas mensais. Nosso portal do cliente e canal direto garantem ajustes rápidos para jantares sociais, viagens e imprevistos.",
    badge: "Zero Desistência"
  },
  {
    step: "04",
    title: "Inteligência de Dados sem Estresse",
    subtitle: "Métricas que ensinam, não que aprisionam",
    description: "Acompanhamos tendência de composição corporal, estabilidade de energia e qualidade de sono. Os números servem para orientar decisões com calma, nunca para gerar obsessão.",
    badge: "Autonomia"
  }
];

export const TRUST_POINTS = [
  {
    value: "100%",
    label: "Individualizado",
    description: "Protocolos desenhados para a sua rotina sem dietas de gaveta"
  },
  {
    value: "75 min",
    label: "Primeira Consulta",
    description: "Tempo clínico de escuta ativa e planejamento seguro"
  },
  {
    value: "Ciência",
    label: "Baseada em Evidências",
    description: "Diretrizes alinhadas a consensos internacionais de metabolismo"
  },
  {
    value: "CFN / CRN",
    label: "Rigor Ético",
    description: "Conduta médica e nutricional em conformidade regulatória"
  }
];
