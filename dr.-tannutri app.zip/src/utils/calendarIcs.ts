import { BookingAppointment } from '../types/booking';
import { CLIENT_INFO } from '../data/canonicalCatalog';

/**
 * Format a Date to iCalendar UTC timestamp format (YYYYMMDDTHHMMSSZ)
 */
function formatDateToICS(date: Date): string {
  const pad = (n: number) => (n < 10 ? '0' + n : n.toString());
  return (
    date.getUTCFullYear().toString() +
    pad(date.getUTCMonth() + 1) +
    pad(date.getUTCDate()) +
    'T' +
    pad(date.getUTCHours()) +
    pad(date.getUTCMinutes()) +
    pad(date.getUTCSeconds()) +
    'Z'
  );
}

/**
 * Parses time string (e.g. "09:30") and date into start and end Date objects
 */
function calculateStartEndDates(date: Date, timeStr: string, durationMinutes: number = 75) {
  const [hours, minutes] = timeStr.split(':').map(Number);
  const startDate = new Date(date);
  startDate.setHours(hours, minutes, 0, 0);

  const endDate = new Date(startDate.getTime() + durationMinutes * 60 * 1000);
  return { startDate, endDate };
}

/**
 * Generates an .ics file Blob and triggers a browser download
 */
export function downloadAppointmentICS(appointment: BookingAppointment) {
  const { startDate, endDate } = calculateStartEndDates(
    appointment.date,
    appointment.slot.time,
    appointment.service.duration.includes('20') ? 30 : 75
  );

  const location =
    appointment.modality === 'presencial'
      ? `Consultório Dr. Tanutri - ${CLIENT_INFO.cityRegion}`
      : `Teleconsulta Online HD (Link enviado via WhatsApp/E-mail)`;

  const description = [
    `Consulta: ${appointment.service.name}`,
    `Modalidade: ${appointment.modality === 'presencial' ? 'Presencial (São Paulo / Jardins)' : 'Teleconsulta Online HD'}`,
    `Paciente: ${appointment.patient.fullName}`,
    `Código de Agendamento: ${appointment.bookingCode}`,
    `Profissional: ${CLIENT_INFO.professionalCoordination}`,
    `Investimento: ${appointment.service.price}`,
    '',
    'Instruções de Preparo:',
    '• Traga ou envie exames de sangue recentes (últimos 6 meses).',
    '• Mantenha registro dos alimentos consumidos nas últimas 48h se possível.',
    '• Para bioimpedância presencial: jejum de 2 a 3 horas.',
    '',
    `Dúvidas e Suporte: ${CLIENT_INFO.primaryWhatsApp}`
  ].join('\\n');

  const icsContent = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Dr. Tanutri//Sistema de Agendamento Online//PT-BR',
    'CALSCALE:GREGORIAN',
    'METHOD:REQUEST',
    'BEGIN:VEVENT',
    `UID:drtanutri-${appointment.bookingCode}-${Date.now()}@drtanutri.com.br`,
    `DTSTAMP:${formatDateToICS(new Date())}`,
    `DTSTART:${formatDateToICS(startDate)}`,
    `DTEND:${formatDateToICS(endDate)}`,
    `SUMMARY:Consulta Nutricional Dr. Tanutri - ${appointment.service.name}`,
    `DESCRIPTION:${description}`,
    `LOCATION:${location}`,
    'STATUS:CONFIRMED',
    'BEGIN:VALARM',
    'TRIGGER:-PT24H',
    'ACTION:DISPLAY',
    'DESCRIPTION:Lembrete: Consulta Nutricional Dr. Tanutri amanhã',
    'END:VALARM',
    'BEGIN:VALARM',
    'TRIGGER:-PT2H',
    'ACTION:DISPLAY',
    'DESCRIPTION:Lembrete: Sua consulta nutricional começa em 2 horas',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR'
  ].join('\r\n');

  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const link = document.createElement('a');
  link.href = window.URL.createObjectURL(blob);
  link.setAttribute('download', `agendamento-dr-tanutri-${appointment.bookingCode}.ics`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Generates a direct Google Calendar Web intent URL
 */
export function getGoogleCalendarUrl(appointment: BookingAppointment): string {
  const { startDate, endDate } = calculateStartEndDates(
    appointment.date,
    appointment.slot.time,
    appointment.service.duration.includes('20') ? 30 : 75
  );

  const formatGCal = (d: Date) => d.toISOString().replace(/-|:|\.\d+/g, '');

  const title = encodeURIComponent(`Consulta Dr. Tanutri - ${appointment.service.name}`);
  const details = encodeURIComponent(
    `Agendamento confirmado com ${CLIENT_INFO.professionalCoordination}.\nCódigo: ${appointment.bookingCode}\nModalidade: ${
      appointment.modality === 'presencial' ? 'Presencial Jardins SP' : 'Telemedicina Online HD'
    }\nContato WhatsApp: ${CLIENT_INFO.primaryWhatsApp}`
  );
  const location = encodeURIComponent(
    appointment.modality === 'presencial'
      ? `Consultório Dr. Tanutri, ${CLIENT_INFO.cityRegion}`
      : 'Teleconsulta Online HD'
  );

  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${formatGCal(
    startDate
  )}/${formatGCal(endDate)}&details=${details}&location=${location}`;
}
