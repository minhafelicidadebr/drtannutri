import React, { useState, useEffect } from 'react';
import { Header } from './components/common/Header';
import { TrustStrip } from './components/common/TrustStrip';
import { Footer } from './components/common/Footer';
import { ConciergeModal } from './components/common/ConciergeModal';
import { TelemetryDrawer } from './components/common/TelemetryDrawer';
import { Hero } from './components/features/Hero';
import { MethodSection } from './components/features/MethodSection';
import { SmartDiagnostic } from './components/features/SmartDiagnostic';
import { InteractiveLab } from './components/features/InteractiveLab';
import { ProgramsSection } from './components/features/ProgramsSection';
import { ClientPortalPreview } from './components/features/ClientPortalPreview';
import { PlansSection } from './components/features/PlansSection';
import { SocialProof } from './components/features/SocialProof';
import { FAQSection } from './components/features/FAQSection';
import { FinalCTA } from './components/features/FinalCTA';
import { BookingModal } from './components/features/booking/BookingModal';
import { ProgramItem, PlanItem } from './types';
import { CLIENT_INFO } from './data/canonicalCatalog';
import { VISUAL_ASSETS } from './data/imageAssets';
import { analytics } from './lib/analytics';
import { Sparkles, MessageCircle, ChevronRight, PhoneCall } from 'lucide-react';

export default function App() {
  const [conciergeOpen, setConciergeOpen] = useState(false);
  const [telemetryOpen, setTelemetryOpen] = useState(false);
  const [conciergePrompt, setConciergePrompt] = useState('');
  const [selectedProgram, setSelectedProgram] = useState<ProgramItem | null>(null);

  // Online Booking Pop-out Modal State
  const [bookingOpen, setBookingOpen] = useState(false);
  const [bookingInitialService, setBookingInitialService] = useState<string | undefined>(undefined);

  // Initialize page analytics
  useEffect(() => {
    analytics.track('page_view', 'engagement', { page: 'home' });
  }, []);

  const handleOpenConcierge = (prompt: string = '') => {
    setConciergePrompt(prompt);
    setConciergeOpen(true);
    analytics.track('ai_concierge_open', 'interaction', { originPrompt: prompt });
  };

  const handleOpenBooking = (serviceId?: string) => {
    setBookingInitialService(serviceId);
    setBookingOpen(true);
    analytics.track('booking_modal_requested', 'navigation', { serviceId: serviceId || 'none' });
  };

  const handleBookProgram = (program: ProgramItem) => {
    setSelectedProgram(program);
    analytics.track('program_booking_intent', 'conversion', { programId: program.id });
    const text = encodeURIComponent(`Olá! Tenho interesse no programa "${program.name}" (${program.duration}) e gostaria de verificar disponibilidade de agenda.`);
    window.open(`https://wa.me/${CLIENT_INFO.whatsAppClean}?text=${text}`, '_blank');
  };

  const handleSelectPlan = (plan: PlanItem) => {
    analytics.track('plan_booking_intent', 'conversion', { planId: plan.id });
    const text = encodeURIComponent(`Olá! Gostaria de agendar o plano "${plan.name}" (${plan.price}). Como podemos proceder?`);
    window.open(`https://wa.me/${CLIENT_INFO.whatsAppClean}?text=${text}`, '_blank');
  };

  const handleExploreLab = () => {
    const el = document.getElementById('lab-interativo');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      analytics.track('explore_lab_scroll', 'navigation');
    }
  };

  const handleExploreTool = (toolId: string) => {
    const el = document.getElementById('lab-interativo');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
    const tabBtn = document.getElementById(`lab-tab-${toolId}`);
    if (tabBtn) {
      tabBtn.click();
    }
    analytics.track('diagnostic_tool_deep_link', 'interaction', { toolId });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#EDF4EA] via-[#E2ECE0] to-[#EBF3E8] text-[#0A160F] selection:bg-[#72B818] selection:text-white relative overflow-x-hidden font-sans">
      
      {/* Global Ambient Lighting Layers - Fresh Chlorophyll & Warm Citrus Sunlight */}
      <div className="fixed inset-0 bg-[radial-gradient(circle_1000px_at_50%_-120px,rgba(114,184,24,0.12),transparent)] pointer-events-none -z-10" aria-hidden="true" />
      <div className="fixed inset-0 bg-[radial-gradient(circle_800px_at_90%_25%,rgba(235,101,26,0.06),transparent)] pointer-events-none -z-10" aria-hidden="true" />
      <div className="fixed inset-0 bg-[radial-gradient(circle_700px_at_10%_65%,rgba(25,135,116,0.06),transparent)] pointer-events-none -z-10" aria-hidden="true" />
      <div className="fixed inset-0 bg-[radial-gradient(circle_900px_at_80%_85%,rgba(235,101,26,0.04),transparent)] pointer-events-none -z-10" aria-hidden="true" />
      
      {/* 1. Global Navigation */}
      <Header 
        onOpenConcierge={() => handleOpenConcierge()} 
        onOpenTelemetry={() => setTelemetryOpen(true)}
        onOpenBooking={handleOpenBooking}
      />

      {/* Main Narrative Sections */}
      <main>
        {/* 2. Hero Section */}
        <Hero 
          onStartDiagnostic={() => {
            const el = document.getElementById('diagnostico');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          onExploreLab={handleExploreLab}
          onOpenConcierge={handleOpenConcierge}
        />

        {/* 3. Clinical Trust Strip */}
        <TrustStrip />

        {/* 4. The Method: Generic vs Dr. Tanutri */}
        <MethodSection />

        {/* 5. Smart Diagnostic: Mapa Inicial 60s */}
        <SmartDiagnostic 
          onSelectProgram={handleBookProgram}
          onExploreTool={handleExploreTool}
          onOpenConcierge={handleOpenConcierge}
        />

        {/* 6. Interactive Lab (Metabolic Twin, Pilot Day, Glucose, Body, 12w) */}
        <InteractiveLab onOpenConcierge={handleOpenConcierge} />

        {/* 7. Clinical Programs & Structured Protocols */}
        <ProgramsSection 
          onBookProgram={handleBookProgram}
          onOpenConcierge={handleOpenConcierge}
        />

        {/* 8. Post-Purchase Experience: Client Portal Preview */}
        <ClientPortalPreview />

        {/* 9. Investment Architecture: Plans & Add-ons */}
        <PlansSection 
          onSelectPlan={handleSelectPlan}
          onOpenConcierge={handleOpenConcierge}
          onOpenBooking={handleOpenBooking}
        />

        {/* 10. Ethical Clinical Evidence & Case Studies */}
        <SocialProof />

        {/* 11. Frequently Asked Questions */}
        <FAQSection onOpenConcierge={handleOpenConcierge} />

        {/* 12. Final Closing & Appointment Scheduling */}
        <FinalCTA 
          onOpenConcierge={handleOpenConcierge}
          onOpenBooking={handleOpenBooking}
        />
      </main>

      {/* 13. Regulatory Compliance Footer */}
      <Footer onOpenTelemetry={() => setTelemetryOpen(true)} />

      {/* 14. Floating Persistent Concierge Trigger with Clara Avatar & High-Converting CTA */}
      <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40">
        <button
          id="floating-concierge-btn"
          onClick={() => handleOpenConcierge()}
          className="group relative flex items-center gap-3 p-1.5 sm:p-2 pr-4 sm:pr-5 rounded-full bg-white/95 backdrop-blur-md border border-[#CCD8C4] hover:border-[#72B818] shadow-[0_16px_40px_rgba(20,40,25,0.18),0_2px_8px_rgba(20,40,25,0.06)] hover:shadow-[0_20px_50px_rgba(114,184,24,0.25)] active:scale-95 transition-all duration-300 cursor-pointer text-left"
          aria-label="Abrir Concierge Clara"
        >
          {/* Avatar com Anel Esmeralda & Beacon de Presença Ativa */}
          <div className="relative shrink-0">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full overflow-hidden border-2 border-[#72B818] shadow-sm bg-[#E2ECE0]">
              <img
                src={VISUAL_ASSETS.conciergeAvatar?.src || ''}
                alt="Clara - Assistente Dr. Tanutri"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-top"
              />
            </div>
            {/* Beacon Pulsante Online */}
            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-[#25D366] border-2 border-white shadow-xs flex items-center justify-center">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping opacity-75" />
            </span>
          </div>

          {/* Microcopy de Ação e Conversão */}
          <div className="flex flex-col justify-center">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-mono-data uppercase font-bold text-[#2C6E14] tracking-wider flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5 text-[#EB651A]" />
                Assistente de IA
              </span>
              <span className="hidden sm:inline-block w-1 h-1 rounded-full bg-[#CCD8C4]" />
              <span className="hidden sm:inline-block text-[10px] font-mono-data text-[#566D5D] font-medium">Online</span>
            </div>
            <span className="text-xs sm:text-sm font-bold text-[#0A160F] leading-snug group-hover:text-[#2C6E14] transition-colors">
              Dúvida sobre qual protocolo escolher?
            </span>
            <span className="text-[11px] text-[#566D5D] hidden sm:block leading-tight">
              Fale com <strong className="text-[#0A160F] font-semibold">Clara</strong> • Resposta em segundos
            </span>
          </div>

          {/* Ícone de Ação */}
          <div className="w-7 h-7 rounded-full bg-[#F2F8ED] border border-[#CCD8C4] group-hover:bg-[#2C6E14] group-hover:text-white group-hover:border-[#2C6E14] text-[#2C6E14] flex items-center justify-center transition-all shrink-0 ml-1 shadow-2xs">
            <ChevronRight className="w-4 h-4" />
          </div>
        </button>
      </div>

      {/* 15. AI Concierge Modal Drawer */}
      <ConciergeModal 
        isOpen={conciergeOpen} 
        onClose={() => setConciergeOpen(false)} 
        initialPrompt={conciergePrompt}
      />

      {/* 16. Telemetry & Microconversion Audit Drawer */}
      <TelemetryDrawer
        isOpen={telemetryOpen}
        onClose={() => setTelemetryOpen(false)}
      />

      {/* 17. Master State-of-the-Art Online Booking Pop-out Modal */}
      <BookingModal
        isOpen={bookingOpen}
        onClose={() => setBookingOpen(false)}
        initialServiceId={bookingInitialService}
        onOpenConcierge={handleOpenConcierge}
      />

    </div>
  );
}
