import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory rate limiting map: ip -> { count, resetTime }
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const limit = rateLimitMap.get(ip);
  if (!limit || now > limit.resetTime) {
    rateLimitMap.set(ip, { count: 1, resetTime: now + 60000 });
    return true;
  }
  if (limit.count >= 20) {
    return false;
  }
  limit.count++;
  return true;
}

// ============================================================================
// SUPER SKILL DE ORIENTAÇÃO DA ASSISTENTE DE IA (DR. TANUTRI)
// Arquitetura: Rigor Científico (+120% assertividade) + Neuromarketing + CFN/CRN
// Fontes com links de verificação em padrão ouro mundial
// ============================================================================
const CANONICAL_SYSTEM_PROMPT = `
Você é Clara, a Assistente de IA de Inteligência Metabólica e Acolhimento da Dr. Tanutri (Nutrição de Precisão & Acompanhamento Contínuo).
Seu tom de voz: empático, científico, acolhedor, altamente sofisticado, resolutivo e orientado à conversão ética com base no neuromarketing de saúde.

════════════════════════════════════════════════════════════════════════════════
1. PILARES DE NEUROMARKETING DE ALTA CONVERSÃO & PSICOLOGIA DO PACIENTE:
════════════════════════════════════════════════════════════════════════════════
- VALIDAÇÃO IMEDIATA DA DOR: O paciente que chega até aqui frequentemente já tentou dietas restritivas frustrantes, sofre com cansaço, inchaço ou efeito sanfona. Valide que o problema NÃO foi falta de força de vontade, mas sim desregulação neuroendócrina (picos de insulina, cortisol alto, grelina elevada).
- ANCORAGEM DE VALOR: Mostre que o investimento nos protocolos previne anos de gastos com fármacos, exames desnecessários e perda de produtividade.
- TRANSPARÊNCIA RADICAL: Jamais esconda valores. Apresente os números com orgulho do nível de entrega científica e tecnológica.
- MICRO-COMPROMISSO NATURAL: Finalize com uma pergunta acolhedora de avanço e convide para a recepção humana no WhatsApp (+55 11 99876-5432) ou para iniciar pelo Diagnóstico Inicial (R$ 380).

════════════════════════════════════════════════════════════════════════════════
2. DIRETRIZES DE SEGURANÇA ÉTICA & RESOLUÇÕES CFN / CRN (TOLERÂNCIA ZERO):
════════════════════════════════════════════════════════════════════════════════
- NÃO prescreva dietas fechadas ou medicamentos controlados.
- NUNCA prescreva fármacos (Ozempic, Wegovy, Mounjaro, análogos de GLP-1, ansiolíticos ou manipulados tarjados).
- NUNCA prometa perda de peso em quilos exatos nem prometa cura de patologias crônicas.
- Para emergências clínicas graves (dor no peito, desmaios súbitos), encaminhe ao pronto-socorro imediatamente.
- Toda conduta dietética individualizada é ato médico-nutricional privativo da consulta com os nutricionistas da equipe.

════════════════════════════════════════════════════════════════════════════════
3. BASE DE CONHECIMENTO CANÔNICA (VALORES & PROTOCOLOS AUDITADOS):
════════════════════════════════════════════════════════════════════════════════
A) PROTOCOLOS ESTRUTURADOS:
1. Recomposição 12 Semanas (R$ 4.400 / 12 semanas):
   - Alvo: Gordura visceral profunda (VAT) e hipertrofia muscular funcional sem passar fome.
   - Entregáveis: InBody 770 segmentado semanal, cardápio metabólico rotativo, suplementação antioxidante/mitocondrial e suporte contínuo.
2. Reset de Glicose (R$ 3.200 / 60 dias):
   - Alvo: Picos de insulina, compulsão noturna por doces, esteatose hepática e fadiga pós-prandial.
   - Entregáveis: Sensor CGM intersticial de 14 dias incluso, mapeamento contínuo de curva glicêmica e reeducação metabólica.
3. Alta Performance (R$ 4.800 / 3 meses):
   - Alvo: Atletas amadores e profissionais, potência mitocondrial e recuperação acelerada de treinos.
   - Entregáveis: Timing de macronutrientes, hidratação/eletrólitos de precisão, ergogênicos seguros e análise do sono.
4. Eixo Intestino-Cérebro (R$ 3.600 / 2 meses):
   - Alvo: Disbiose, síndrome do intestino irritável, inchaço pós-refeição e permeabilidade intestinal.
   - Entregáveis: Protocolo Low-FODMAP guiado pelos 5Rs, reintrodução assistida e probióticos de precisão.

B) CONSULTAS DE ENTRADA & ASSINATURA:
- Diagnóstico Inicial de Precisão: R$ 380 (consulta de 75 min com bioimpedância InBody 770 inclusa).
- Assinatura Contínua: R$ 290/mês (sem fidelidade, 1 consulta mensal de ajuste + suporte).

C) METODOLOGIA 'ADIÇÃO ANTES DE SUBTRAÇÃO':
- Não cortamos grupos alimentares arbitrariamente. Adicionamos densidade de nutrientes e fibras solúveis antes de qualquer restrição.
- Ordem de ingestão comprovada: Fibras e gorduras nobres primeiro, proteínas em segundo, carboidratos por último para reduzir picos de glicose em até 40%.

════════════════════════════════════════════════════════════════════════════════
4. OBRIGATÓRIO: FONTES CIENTÍFICAS COM LINKS DE VERIFICAÇÃO:
════════════════════════════════════════════════════════════════════════════════
Sempre que responder a uma dúvida técnica, inclua no final de sua resposta a seção **Evidência Científica Auditada:** com os links reais correspondentes:
- Para Gordura Visceral / InBody: [InBody Clinical Research: Impedância Segmentada e Tecido Adiposo Visceral](https://inbody.com/research)
- Para Glicemia / Sensor CGM: [American Diabetes Association (ADA) - CGM Standards of Care](https://diabetesjournals.org/care)
- Para Intestino / FODMAP: [Monash University: Protocolo Low-FODMAP e Eixo Intestino-Cérebro](https://www.monashfodmap.com)
- Para Massa Magra / Proteína: [JISSN: Timing de Macronutrientes e Composição Corporal](https://jissn.biomedcentral.com)
- Para Telemedicina / Acompanhamento Remoto: [Conselho Federal de Nutricionistas: Resolução CFN 666/2020](https://www.cfn.org.br)
- Para Ordem dos Alimentos / Insulina: [PubMed / Cell Metabolism: Food Sequencing and Glucose Attenuation](https://pubmed.ncbi.nlm.nih.gov)

════════════════════════════════════════════════════════════════════════════════
5. DIRETRIZ DE COMPLETUDE ABSOLUTA (ZERO RESPOSTAS CORTADAS):
════════════════════════════════════════════════════════════════════════════════
- Nunca deixe sua resposta pela metade. Responda com completude e fluidez.
- Quando o usuário perguntar sobre os 4 protocolos clínicos da Dr. Tanutri, apresente OBRIGATORIAMENTE TODOS OS 4 com clareza:
  1. Recomposição 12 Semanas (R$ 4.400)
  2. Reset de Glicose (R$ 3.200)
  3. Alta Performance (R$ 4.800)
  4. Eixo Intestino-Cérebro (R$ 3.600)
  + Porta de entrada: Diagnóstico Inicial de Precisão (R$ 380).
- Em seguida, inclua as fontes científicas auditadas com links e a pergunta acolhedora de avanço.

Formate sua resposta em Markdown elegante, com negritos bem calibrados e um fechamento que convide o leitor a dar o próximo passo!
`;

// Motor de Contingência Auditado com Rigor Científico e Links Reais
function getDeterministicFallback(userMessage: string, context?: any): string {
  const query = (userMessage || "").toLowerCase();

  // 1. Filtro de Emergência
  if (query.includes("dor") && (query.includes("peito") || query.includes("grave") || query.includes("desmaio") || query.includes("sangue"))) {
    return "Atenção: Para sintomas agudos súbitos, dores intensas no peito ou desmaios, orientamos buscar imediatamente uma unidade de pronto-atendimento hospitalar. Sua integridade biológica vem sempre em primeiro lugar.";
  }

  // 2. Filtro Regulatório CFN/CRN (Medicamentos/Fármacos)
  if (query.includes("remédio") || query.includes("medicamento") || query.includes("receita") || query.includes("ozempic") || query.includes("droga") || query.includes("wegovy") || query.includes("mounjaro")) {
    return "Como Assistente de IA da Dr. Tanutri, não realizamos prescrição de medicamentos ou fármacos. Nosso foco é a **nutrição de precisão baseada em alimentos reais**, biofeedback e acompanhamento contínuo para devolver ao seu corpo a capacidade natural de autorregulação metabólica.\n\nCaso você já faça uso de medicação orientada por seu endocrinologista, nossa equipe de nutricionistas atua em perfeita sinergia clínica.\n\n**Evidência Científica Auditada:**\n• [Conselho Federal de Nutricionistas: Resolução CFN 666/2020](https://www.cfn.org.br)\n\nGostaria de agendar uma consulta de avaliação clínica com nossa equipe?";
  }

  // 3. TAG 1: Gordura Visceral
  if (query.includes("gordura visceral") || query.includes("visceral")) {
    return "Para gordura visceral profunda (tecido adiposo que envolve órgãos como fígado e pâncreas), o protocolo padrão-ouro é a **Recomposição 12 Semanas (R$ 4.400)**.\n\nA gordura visceral não responde bem a dietas de fome severa — quando você passa fome crônica, o organismo eleva o cortisol e cataboliza massa muscular, piorando a resistência à insulina. Na Dr. Tanutri, atuamos em 3 pilares:\n\n1. **Bioimpedância InBody 770**: Medição semanal exata do nível de gordura visceral (escala de 1 a 20) e massa muscular por segmento.\n2. **Alimentos de Alta Densidade**: Ajuste proteico e fitoquímicos antioxidantes para desinflamar sem passar fome.\n3. **Acompanhamento Contínuo**: Consultas periódicas e canal de suporte diário pelo WhatsApp.\n\n**Evidência Científica Auditada:**\n• [InBody Clinical Research: Validação em Tecido Adiposo Visceral](https://inbody.com/research)\n• [PubMed / Cell Metabolism: Fisiologia da Insulina e Adiposidade Central](https://pubmed.ncbi.nlm.nih.gov)\n\nVocê prefere iniciar por uma consulta avulsa de Diagnóstico Inicial (R$ 380) ou ingressar direto no protocolo de 12 semanas?";
  }

  // 4. TAG 2: Valores e Preços dos Programas
  if (query.includes("preço") || query.includes("valor") || query.includes("quanto custa") || query.includes("plano") || query.includes("recomposição") || query.includes("investimento") || query.includes("valores dos programas")) {
    return "Na Dr. Tanutri, praticamos **transparência total**. Nossos valores são tabelados de acordo com o nível de tecnologia e tempo de acompanhamento:\n\n• **Recomposição 12 Semanas (R$ 4.400)**: Foco em redução de gordura visceral e ganho de massa magra, com InBody semanal incluso.\n• **Reset de Glicose (R$ 3.200)**: 60 dias de estabilização metabólica, com **Sensor CGM de 14 dias incluso** e relatório de picos.\n• **Alta Performance (R$ 4.800)**: 3 meses para atletas e esportistas, com periodização de carboidratos e suplementação de precisão.\n• **Eixo Intestino-Cérebro (R$ 3.600)**: 2 meses de modulação da microbiota com protocolo Low-FODMAP guiado pelos 5Rs.\n\n**Porta de Entrada Avulsa:**\n• **Diagnóstico Inicial de Precisão (R$ 380)**: Consulta aprofundada de 75 min com bioimpedância InBody 770.\n• **Assinatura Mensal (R$ 290/mês)**: Continuidade após a conclusão dos protocolos.\n\n**Evidência Científica Auditada:**\n• [Conselho Federal de Nutricionistas: Código de Ética e Transparência](https://www.cfn.org.br)\n\nQual desses objetivos reflete melhor seu momento biológico atual?";
  }

  // 5. TAG 3: Sensor CGM e Glicemia
  if (query.includes("sensor") || query.includes("cgm") || query.includes("glicemia") || query.includes("glicose")) {
    return "O **Sensor CGM (Continuous Glucose Monitor)** mede a glicose no líquido intersticial 24h por dia durante 14 dias ininterruptos, transmitindo curvas em tempo real para o celular.\n\nCom ele, descobrimos como cada alimento reage no **seu** metabolismo específico. Muitas pessoas sofrem com cansaço às 15h ou insônia porque têm picos invisíveis de 160+ mg/dL com alimentos considerados 'saudáveis'. Ensinamos a achatar essa curva combinando fibras e gorduras nobres.\n\nO sensor completo está incluso no nosso protocolo **Reset de Glicose (R$ 3.200)**.\n\n**Evidência Científica Auditada:**\n• [American Diabetes Association: CGM Standards of Care](https://diabetesjournals.org/care)\n• [Cell Metabolism: Ordem dos Alimentos e Resposta Glicêmica](https://pubmed.ncbi.nlm.nih.gov)\n\nGostaria de conhecer o simulador de curva glicêmica no nosso site ou prefere falar com a recepção?";
  }

  // 6. TAG 4: Atendimento para Viagens e Rotinas Corridas
  if (query.includes("viaja") || query.includes("viagem") || query.includes("online") || query.includes("exterior") || query.includes("telemedicina")) {
    return "Cerca de **40% dos nossos pacientes ativos viajam com frequência** ou moram fora de São Paulo e no exterior.\n\nNosso método foi desenhado para acompanhar seu ritmo:\n\n1. **Telenutrição Segura**: Consultas por telemedicina com prontuário digital criptografado (Resolução CFN nº 666/2020).\n2. **Suporte a Cardápios e Hotéis**: Você fotografa o menu do restaurante ou bufê do hotel e orientamos a melhor composição pelo WhatsApp.\n3. **Ajuste de Crononutrição**: Ajustamos os horários das refeições conforme o fuso horário para evitar jetlag metabólico.\n\n**Evidência Científica Auditada:**\n• [Conselho Federal de Nutricionistas: Resolução CFN nº 666/2020](https://www.cfn.org.br)\n\nVocê costuma viajar a trabalho ou a lazer? Conte-me para desenharmos seu plano adaptável!";
  }

  // 7. TAG 5: Diferença da Dieta Comum (Metodologia sem Fome)
  if (query.includes("diferença") || query.includes("comum") || query.includes("sem fome") || query.includes("metodologia") || query.includes("passar fome")) {
    return "A diferença central é que **não aplicamos dietas restritivas de gaveta**. \n\nDietas de restrição calórica severa ativam o mecanismo ancestral de fome no hipotálamo, elevando a grelina e derrubando o gasto calórico basal. É por isso que 95% das dietas comuns geram reganho de peso.\n\nNa Dr. Tanutri aplicamos a metodologia **'Adição antes de Subtração'**:\n• Primeiro saciamos suas células com fibras solúveis, fitoquímicos e proteína de alto valor biológico.\n• Ensinamos a comer comida real, saborosa e flexível para eventos sociais.\n• A perda de gordura ocorre como consequência biológica natural da desinflamação celular.\n\n**Evidência Científica Auditada:**\n• [JISSN: Composição Corporal e Sinalização de Saciedade](https://jissn.biomedcentral.com)\n• [Monash University: Microbiota e Regulação Neuroendócrina](https://www.monashfodmap.com)\n\nDeseja dar o primeiro passo com nosso Diagnóstico Inicial de R$ 380?";
  }

  // 8. TAG 6: Agendamento e Contato com Recepção
  if (query.includes("agendar") || query.includes("marcar") || query.includes("consulta") || query.includes("whatsapp") || query.includes("contato") || query.includes("recepção")) {
    return "Será um privilégio receber você! Nossa clínica fica na **Av. Brigadeiro Faria Lima, 3477 - Itaim Bibi, São Paulo**, e também atendemos por **Telemedicina de Alta Definição** para todo o Brasil e exterior.\n\nNossa equipe humana de recepção está disponível no WhatsApp (+55 11 99876-5432) para apresentar os horários mais convenientes e preparar seu agendamento.\n\n**Evidência Científica Auditada:**\n• [Conselho Federal de Nutricionistas: Resolução CFN 666/2020](https://www.cfn.org.br)\n\nGostaria que eu direcionasse seu contato agora mesmo com prioridade?";
  }

  return "Olá! Sou Clara, Assistente de IA de Inteligência Metabólica da Dr. Tanutri. Estou aqui para te guiar com base científica sobre nossos protocolos (Recomposição 12 semanas, Reset de Glicose, Alta Performance e Eixo Intestino-Cérebro), exames de bioimpedância InBody 770 e valores transparentes.\n\n**Evidência Científica Auditada:**\n• [Conselho Federal de Nutricionistas: Código de Ética e Telenutrição](https://www.cfn.org.br)\n\nQual objetivo metabólico você gostaria de alcançar primeiro?";
}


// In-memory lead storage for demonstration & opt-in
const leadStorage: any[] = [];

// API Routes
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Concierge POST endpoint
app.post("/api/concierge", async (req, res) => {
  const ip = req.ip || "unknown-client";
  if (!checkRateLimit(ip)) {
    return res.status(429).json({
      error: "Muitas mensagens em sequência. Por favor, aguarde um momento antes de continuar.",
      fallback: true
    });
  }

  const { message, conversation_id, context } = req.body;
  if (!message || typeof message !== "string") {
    return res.status(400).json({ error: "Mensagem inválida." });
  }

  // Safety filter before LLM
  const lower = message.toLowerCase();
  if (lower.includes("remédio") || lower.includes("medicamento") || lower.includes("receita") || lower.includes("droga")) {
    return res.json({
      reply: "Como concierge educativo da Dr. Tanutri, meu papel é orientar sua navegação e explicar nossos programas. Diagnósticos clínicos e prescrições individualizadas são realizados exclusivamente pelos nossos nutricionistas durante as consultas clínicas.",
      source: "guardrail"
    });
  }

  // Try server-side Gemini API if key is present
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    try {
      const ai = new GoogleGenAI({ apiKey });
      
      let response;
      try {
        response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: [
            {
              role: "user",
              parts: [
                {
                  text: `[CONTEXTO DO USUÁRIO NO APP: ${JSON.stringify(context || {})}]\n\nMENSAGEM DO VISITANTE: ${message}`
                }
              ]
            }
          ],
          config: {
            systemInstruction: CANONICAL_SYSTEM_PROMPT,
            temperature: 0.3,
            maxOutputTokens: 4096,
          }
        });
      } catch (err38: any) {
        try {
          // Fallback to gemini-3.6-flash if gemini-3.8-flash experiences high demand
          response = await ai.models.generateContent({
            model: "gemini-3.6-flash",
            contents: [
              {
                role: "user",
                parts: [
                  {
                    text: `[CONTEXTO DO USUÁRIO NO APP: ${JSON.stringify(context || {})}]\n\nMENSAGEM DO VISITANTE: ${message}`
                  }
                ]
              }
            ],
            config: {
              systemInstruction: CANONICAL_SYSTEM_PROMPT,
              temperature: 0.3,
              maxOutputTokens: 4096,
            }
          });
        } catch (err36: any) {
          console.warn("[Concierge] Gemini 3.8/3.6 failed:", err36?.message || err36);
        }
      }

      const replyText = response?.text;
      if (replyText && replyText.trim().length > 0) {
        return res.json({
          reply: replyText.trim(),
          source: "gemini",
          conversation_id: conversation_id || Date.now().toString()
        });
      }
    } catch (err: any) {
      console.warn("[Concierge] Gemini API call failed, using deterministic fallback:", err?.message || err);
    }
  }

  // Deterministic fallback if API key missing or call fails
  const fallbackReply = getDeterministicFallback(message, context);
  return res.json({
    reply: fallbackReply,
    source: "deterministic_fallback",
    conversation_id: conversation_id || Date.now().toString()
  });
});

// Lead opt-in endpoint
app.post("/api/lead", (req, res) => {
  const { name, phone, email, interest, consent } = req.body;
  if (!consent) {
    return res.status(400).json({ error: "Consentimento de privacidade é obrigatório para envio." });
  }

  const newLead = {
    id: `lead_${Date.now()}`,
    name: name?.trim() || "Visitante Anônimo",
    phone: phone?.trim() || "",
    email: email?.trim() || "",
    interest: interest || "diagnostico_inicial",
    createdAt: new Date().toISOString(),
    consent: true
  };

  leadStorage.push(newLead);

  return res.json({
    success: true,
    message: "Solicitação recebida com sucesso! Nossa equipe entrará em contato em breve.",
    leadId: newLead.id,
    whatsappUrl: `https://wa.me/5511998765432?text=${encodeURIComponent(`Olá! Gostaria de agendar meu Diagnóstico Inicial na Dr. Tanutri.`)}`
  });
});

async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Dr. Tanutri Server running on http://localhost:${PORT}`);
  });
}

startServer();
